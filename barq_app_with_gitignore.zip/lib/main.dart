import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

void main() {
  runApp(const BarqApp());
}

class BarqApp extends StatelessWidget {
  const BarqApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Barq',
      debugShowCheckedModeBanner: false,
      home: const ImageSequenceScreen(),
    );
  }
}

class ImageSequenceScreen extends StatefulWidget {
  const ImageSequenceScreen({Key? key}) : super(key: key);

  @override
  State<ImageSequenceScreen> createState() => _ImageSequenceScreenState();
}

class _ImageSequenceScreenState extends State<ImageSequenceScreen> {
  final List<String> _images = [
    'assets/images/img2.jpg',
    'assets/images/img3.jpg',
    'assets/images/img4.jpg',
    'assets/images/img5.jpg',
    'assets/images/img6.jpg',
  ];

  int _index = 0;
  DateTime? _lastTap;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      for (final path in _images) {
        final image = AssetImage(path);
        await precacheImage(image, context);
      }
      Future.delayed(const Duration(seconds: 2), () {
        if (mounted) {
          setState(() {
            _index = 1;
          });
        }
      });
    });
  }

  void _handleTap() async {
    if (_index < _images.length - 1) {
      setState(() {
        _index++;
      });
      return;
    }
    final now = DateTime.now();
    if (_lastTap == null || now.difference(_lastTap!) > const Duration(milliseconds: 600)) {
      _lastTap = now;
      return;
    }
    final Uri emailLaunchUri = Uri(
      scheme: 'mailto',
      path: 'ccs@barq.com',
      query: Uri(queryParameters: {'subject': 'Support request from Barq app'}).query,
    );
    try {
      await launchUrl(emailLaunchUri);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not open email client')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _handleTap,
        child: Center(
          child: Image.asset(
            _images[_index],
            width: double.infinity,
            height: double.infinity,
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}