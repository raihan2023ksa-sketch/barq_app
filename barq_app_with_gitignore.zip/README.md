# Barq Flutter App

A simple Flutter app that shows a sequence of images and sends an email on double tap.

## How it works
- Shows the 2nd image first.
- After 2 seconds, automatically shows the 3rd image.
- Tap anywhere to load the next image (4th, 5th, 6th).
- Double-tap on the last image to open your email app to send mail to `ccs@barq.com`.

## How to build

1. Install Flutter SDK (if not already installed).
2. Run `flutter pub get` in the project folder.
3. Build APK: `flutter build apk --release`
4. APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## For Codemagic
Push this folder to GitHub, connect to Codemagic, and set Flutter build target to Android → APK.